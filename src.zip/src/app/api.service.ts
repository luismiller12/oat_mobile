import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpClient: HttpClient) { }

  getPosts(page){
    return this.httpClient.get(`http://localhost:1337/carros`);
  }

  sendPostRequest(postData) {

    const httpOptions = {
      headers: new HttpHeaders({
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        })
    };


    return this.httpClient.post("http://localhost:1337/carros", postData, httpOptions);
    
  }

  sendPutRequest(id, postData) {

    const httpOptions = {
      headers: new HttpHeaders({
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        })
    };

    return this.httpClient.put(`http://localhost:1337/carros/${id}`, postData, httpOptions);
    
  }

  sendDeleteRequest(id){
    return this.httpClient.delete(`http://localhost:1337/carros/${id}`);
  }

}
